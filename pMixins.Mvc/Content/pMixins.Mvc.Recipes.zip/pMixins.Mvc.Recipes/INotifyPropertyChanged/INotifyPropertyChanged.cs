﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CopaceticSoftware.pMixins.Attributes;
using CopaceticSoftware.pMixins.Infrastructure;

namespace pMixins.Mvc.Recipes.INotifyPropertyChanged
{

    public interface ISomeInterface
    {
        void SomeMethod();
    }

    public class SomeInterfaceImplementation : ISomeInterface
    {
        public void SomeMethod()
        {
            throw new NotImplementedException();
        }
    }

    [pMixin(Mixin = typeof(SomeInterfaceImplementation))]
    public partial class Target { }

    public class Utility
    {
        public void DoSomeWorkOnSomeInterface(ISomeInterface obj)
        {
            obj.SomeMethod();
        }

        public void DoSomeWorkOnImplementation(SomeInterfaceImplementation obj)
        {
            obj.SomeMethod();
        }
    }

    class Program
    {
        private static void Main(string[] args)
        {
            //Call the mixed in method
            new Target().SomeMethod();

            //Target implements ISomeInterface is code-behind
            new Utility().DoSomeWorkOnSomeInterface(new Target());

            //Target has an implicit conversion operator to SomeInterfaceImplementation in code-behind
            new Utility().DoSomeWorkOnImplementation(new Target());
        }
    }


    public class NotifyPropertyChanged
    {
    }
}
