﻿//----------------------------------------------------------------------- 
// <copyright file="VirtualMethodOverrideTest.cs" company="Copacetic Software"> 
// Copyright (c) Copacetic Software.  
// <author>Philip Pittle</author> 
// <date>Wednesday, July 9, 2014 10:52:31 PM</date> 
// Licensed under the Apache License, Version 2.0,
// you may not use this file except in compliance with this License.
//  
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an 'AS IS' BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// </copyright> 
//-----------------------------------------------------------------------

using NUnit.Framework;

namespace pMixins.Mvc.Recipes.VirtualMethodOverride
{
    public class VirtualMethodOverrideTest
    {
        [Test]
        public void MemberOverriddenInTarget()
        {
            Assert.AreEqual(
                "Target",
                new VirtualMethodOverride().GetName());
        }

        [Test]
        public void MemberOverriddenInChild()
        {
            Assert.AreEqual(
                "Child",
                new Child().GetName());
        }
    }
}
